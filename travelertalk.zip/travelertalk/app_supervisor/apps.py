from django.apps import AppConfig

class AppSupervisorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_supervisor'
